﻿import discord,os,random,setting
from discord.ext import commands

bot = commands.Bot(command_prefix="!")
regichannel = 990915085520212008

def embed(embedtype, embedtitle, description):
    if (embedtype == "error"):
        return discord.Embed(color=0xDBE6F6, title=embedtitle, description=description)
    if (embedtype == "success"):
        return discord.Embed(color=0xDBE6F6, title=embedtitle, description=description)

@bot.event
async def on_ready():
    print("[+] NewProject GEN BOT ON!")
    while True:
        await bot.change_presence(activity=discord.Game("SY BOT HOSTING SERVICE"),status=discord.Status.online)

@bot.command()
async def 재고(ctx):
    stockmenu = discord.Embed(color=0xDBE6F6, title="SY Premium GEN", description="")
    for filename in os.listdir("stock"):
        with open("stock\\"+filename) as f:
            ammount = len(f.read().splitlines())
            name = (filename[0].upper() + filename[1:].lower()).replace(".txt","")
            stockmenu.description += f"제품 : `{name}`ㅣ재고 : `{ammount}개`\n"
    await ctx.reply(embed=stockmenu)

@bot.command()
async def 젠(ctx,name=None):
    if name == None:
        await ctx.reply(embed=embed("error", "SY Premium GEN", "플랫폼 이름을 입력해주세요."))
    else:
        name = name.lower()+".txt"
        if name not in os.listdir("stock"):
            await ctx.reply(embed=embed("error", "SY Premium GEN", "해당 제품을 찾지 못하였습니다."))
        else:
            with open("stock\\"+name) as file:
                lines = file.read().splitlines()
            if len(lines) == 0:
                await ctx.reply(embed=embed("error", "SY Premium GEN", "해당 제품의 재고가 부족합니다."))
            else:
                with open("stock\\"+name) as file:
                    account = random.choice(lines) 
                try: 
                    if ctx.channel.id == regichannel:
                        await ctx.author.send(embed=embed("success", "NewProject GEN", f"||``{account}``||"))
                except: 
                    await ctx.reply(embed=embed("error", "SY Premium GEN", "개인메시지를 허용해 주세요."))
                else: 
                    if ctx.channel.id == regichannel:
                        await ctx.reply(embed=embed("success", "SY Premium GEN", "DM을 확인해 주세요."))
                    with open("stock\\"+name,"w") as file:
                        file.write("") 
                    with open("stock\\"+name,"a") as file:
                        for line in lines: 
                            if line != account: 
                                file.write(line+"\n") 

bot.run(setting.token)